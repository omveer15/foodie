import 'package:flutter/material.dart';

class DonePage extends StatefulWidget {
  const DonePage({Key? key}) : super(key: key);

  @override
  State<DonePage> createState() => _DonePageState();
}

class _DonePageState extends State<DonePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
        elevation: 0.0,
        title: Text("",textAlign: TextAlign.center,style: TextStyle(fontSize: 30)),
        backgroundColor: Colors.orange,
        ),
        body: Center(
          child: Column(
            children: [
              Image.asset('assets/tick1.jpg'),
              Text('Ordered',style: TextStyle(fontSize: 30,fontWeight: FontWeight.bold),),
            ],
          ),
        ),
    );
  }
}
