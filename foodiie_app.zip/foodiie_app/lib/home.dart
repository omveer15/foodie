import 'package:flutter/material.dart';
import 'package:foodiie_app/about.dart';
import 'package:foodiie_app/contactus.dart';
import 'package:foodiie_app/myburger.dart';
import 'package:foodiie_app/mycake.dart';
import 'package:foodiie_app/myfries.dart';
import 'package:foodiie_app/myhelp.dart';
import 'package:foodiie_app/mymomos.dart';
import 'package:foodiie_app/mynoodles.dart';
import 'package:foodiie_app/mypizza.dart';


class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      //key: key,
      appBar: AppBar(
        elevation: 0.0,
        title: Text("Foodie!",textAlign: TextAlign.center,style: TextStyle(fontSize: 30)),
        backgroundColor: Colors.orange,
      ),
      body: ListView(
        children: [

          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            color: Colors.orangeAccent,
            child: Row(
              children: [
                Image(image: AssetImage('assets/pizza_1.jpg'),fit: BoxFit.fill,
                width: 140,
                  height: 140,
                ),
                Text('Pizza\n₹180',style: TextStyle(fontSize: 30),textAlign: TextAlign.left,),
                Container(
                  child: IconButton(
                    iconSize: 30,
                    icon: const Icon(Icons.arrow_forward), onPressed: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context)=> const MyPizza()),); },
                    alignment: Alignment.bottomRight,color: Colors.orangeAccent,
                  ),
                ),
              ],
            ),
          ),
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            color: Colors.orangeAccent,
            child: Row(
              children: [
                Image(image: AssetImage('assets/burger_1.jpg'),fit: BoxFit.contain,
                  width: 140,
                  height: 140,
                ),
                Text('Burger\n₹80',style: TextStyle(fontSize: 30),textAlign: TextAlign.left,),
                Container(
                  child: IconButton(
                    iconSize: 30,
                    icon: const Icon(Icons.arrow_forward), onPressed: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context)=> const MyBurger()),); },
                    alignment: Alignment.bottomRight,color: Colors.orangeAccent,
                  ),
                ),
              ],
            ),
          ),
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            color: Colors.orangeAccent,
            child: Row(
              children: [
                Image(image: AssetImage('assets/cake_1.jpg'),fit: BoxFit.contain,
                  width: 140,
                  height: 140,
                ),
                Text('Cake\n₹350',style: TextStyle(fontSize: 30),textAlign: TextAlign.left,),
                Container(
                  child: IconButton(
                    iconSize: 30,
                    icon: const Icon(Icons.arrow_forward), onPressed: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context)=> const MyCake()),);
                  },alignment: Alignment.bottomRight,color: Colors.orangeAccent,
                  ),
                ),
              ],
            ),
          ),
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            color: Colors.orangeAccent,
            child: Row(
              children: [
                Image(image: AssetImage('assets/fries_1.jpg'),fit: BoxFit.fill,
                  width: 140,
                  height: 140,
                ),
                Text('Fries\n₹120',style: TextStyle(fontSize: 30),textAlign: TextAlign.left,),
                Container(
                  child: IconButton(
                    iconSize: 30,
                    icon: const Icon(Icons.arrow_forward), onPressed: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context)=> const MyFries()),);
                  },alignment: Alignment.bottomRight,color: Colors.orangeAccent,
                  ),
                ),
              ],
            ),
          ),
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            color: Colors.orangeAccent,
            child: Row(
              children: [
                Image(image: AssetImage('assets/momos_1.jpg'),fit: BoxFit.fill,
                  width: 140,
                  height: 140,
                ),
                Text('Momos\n₹80',style: TextStyle(fontSize: 30),textAlign: TextAlign.left,),
                Container(
                  child: IconButton(
                    iconSize: 30,
                    icon: const Icon(Icons.arrow_forward), onPressed: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context)=> const MyMomos()),);
                  },alignment: Alignment.bottomRight,color: Colors.orangeAccent,
                  ),
                ),
              ],
            ),
          ),
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            color: Colors.orangeAccent,
            child: Row(
              children: [
                Image(image: AssetImage('assets/noodles_1.jpg'),fit: BoxFit.contain,
                  width: 140,
                  height: 140,
                ),
                Text('Noodles\n₹120',style: TextStyle(fontSize: 30),textAlign: TextAlign.left,),
                Container(
                  child: IconButton(
                    iconSize: 30,
                    icon: const Icon(Icons.arrow_forward), onPressed: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context)=> const MyNoodles()),);
                  },alignment: Alignment.bottomRight,color: Colors.orangeAccent,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.orange,
              ),
              child: Text('Welcome',style: TextStyle(color: Colors.white,fontSize: 40),),
              padding: EdgeInsets.only(left: 80,top: 65),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TextButton(
                  onPressed: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context)=> const MyHelp()),);
                  },
                  child: Text(
                    'Help',
                    textAlign: TextAlign.left,
                    style: TextStyle(
                        color: Colors.black,
                        fontSize: 23.5),
                  ),
                ),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TextButton(
                  onPressed: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context)=> const ContactUs()),);
                  },
                  child: Text(
                    'Contact Us',
                    textAlign: TextAlign.left,
                    style: TextStyle(
                        color: Colors.black,
                        fontSize: 23.5),
                  ),
                ),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TextButton(
                  onPressed: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context)=> const About()),);
                  },
                  child: Text(
                    'About',
                    textAlign: TextAlign.left,
                    style: TextStyle(
                        color: Colors.black,
                        fontSize: 23.5),
                  ),
                ),
              ],
            ),
          ],
        ),
        ),
      );
  }
}


