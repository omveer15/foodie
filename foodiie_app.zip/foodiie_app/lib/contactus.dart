import 'package:flutter/material.dart';

class ContactUs extends StatefulWidget {
  const ContactUs({Key? key}) : super(key: key);

  @override
  State<ContactUs> createState() => _ContactUsState();
}

class _ContactUsState extends State<ContactUs> {
  @override
  Widget build(BuildContext context) {
    return Container(
      //padding: EdgeInsets.only(left: 30,top: 10),
      child: Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
          child: Text('Contact No. : +91 8126143303\n Email : deepak.parihar_cs20@gla.ac.in\nEmail : suchita.khare_cs20@gla.ac.in\n'
              'Email : akash.rathore_cs20@gla.ac.in\nEmail : nitish.baghel_cs20@gla.ac.in'
              '\nEmail : omveer.chaudhary_cs20@gla.ac.in',style: TextStyle(color: Colors.black,fontSize: 20,fontWeight: FontWeight.bold)),
        ),
        appBar: AppBar(
          elevation: 0.0,
          title: Text("Contact Us",textAlign: TextAlign.center,style: TextStyle(fontSize: 30)),
          backgroundColor: Colors.orange,
        ),
      ),
    );
  }
}
