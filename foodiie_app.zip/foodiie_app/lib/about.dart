import 'package:flutter/material.dart';

class About extends StatefulWidget {
  const About({Key? key}) : super(key: key);

  @override
  State<About> createState() => _AboutState();
}

class _AboutState extends State<About> {
  @override
  Widget build(BuildContext context) {
    return Container(
      //padding: EdgeInsets.only(left: 30,top: 10),
      child: Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
          child: Text('This application helps everyone to pre-order your meal and also saves their time.',style: TextStyle(color: Colors.black,fontSize: 20,fontWeight: FontWeight.bold)),
        ),
        appBar: AppBar(
          elevation: 0.0,
          title: Text("About Us",textAlign: TextAlign.center,style: TextStyle(fontSize: 30)),
          backgroundColor: Colors.orange,
        ),
      ),
    );
  }
}
