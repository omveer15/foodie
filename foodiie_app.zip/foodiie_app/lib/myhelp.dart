import 'package:flutter/material.dart';

class MyHelp extends StatefulWidget {
  const MyHelp({Key? key}) : super(key: key);

  @override
  State<MyHelp> createState() => _MyHelpState();
}

class _MyHelpState extends State<MyHelp> {
  @override
  Widget build(BuildContext context) {
    return Container(
      //padding: EdgeInsets.only(left: 30,top: 10),
      child: Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
         child: Text('  Please mail your problem to us ,So that we can help\n   you.\n \n  Thank You\n'
          '\n Email id : deepak.parihar_cs20@gla.ac.in',style: TextStyle(color: Colors.black,fontSize: 20,fontWeight: FontWeight.bold)),
        ),
        appBar: AppBar(
          elevation: 0.0,
          title: Text("Help",textAlign: TextAlign.center,style: TextStyle(fontSize: 30)),
          backgroundColor: Colors.orange,
        ),
    ),
    );
  }
}
