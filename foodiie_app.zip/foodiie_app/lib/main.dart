import 'package:flutter/material.dart';
import 'package:foodiie_app/donepage.dart';
import 'package:foodiie_app/login.dart';
import 'package:foodiie_app/myburger.dart';
import 'package:foodiie_app/mycake.dart';
import 'package:foodiie_app/myfries.dart';
import 'package:foodiie_app/myhelp.dart';
import 'package:foodiie_app/mymomos.dart';
import 'package:foodiie_app/mynoodles.dart';
import 'package:foodiie_app/mypizza.dart';
import 'package:foodiie_app/register.dart';
import 'package:foodiie_app/welcome.dart';
import 'package:foodiie_app/home.dart';


void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    initialRoute: 'welcome',
    routes: {
      'welcome': (context) => Welcome(),
      'register': (context) => MyRegister(),
      'login': (context) => MyLogin(),
      'home' : (context) => Home(),
      'myhelp': (context) => MyHelp(),
      'mypizza': (context)=>MyPizza(),
      'myburger': (context)=>MyBurger(),
      'mycake': (context)=>MyCake(),
      'myfries': (context)=>MyFries(),
      'mymomos': (context)=>MyMomos(),
      'mynoodles': (context)=>MyNoodles(),
      'donepage' : (context)=> DonePage(),
    },
  )
  );
  }
