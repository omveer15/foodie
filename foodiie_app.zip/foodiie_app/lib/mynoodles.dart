import 'package:flutter/material.dart';
import 'package:foodiie_app/donepage.dart';

class MyNoodles extends StatefulWidget {
  const MyNoodles({Key? key}) : super(key: key);

  @override
  State<MyNoodles> createState() => _MyNoodlesState();
}

class _MyNoodlesState extends State<MyNoodles> {
  int _count6=0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0.0,
        title: Text("",textAlign: TextAlign.center,style: TextStyle(fontSize: 30)),
        backgroundColor: Colors.orange,
      ),
      body: Center(
        child: Column(
          children: [
            Image.asset('assets/noodles_1.jpg'),
            Text('Noodles\n₹120',style: TextStyle(fontSize: 30,fontWeight: FontWeight.bold),),
            Text('\nDescription : Veg Hot Spicy Noodles',style: TextStyle(fontSize: 20),),
            SizedBox(
              height: 20,
            ),
            TextField(
              style: TextStyle(color: Colors.orange),
              decoration: InputDecoration(
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: BorderSide(
                      color: Colors.orange,
                    ),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: BorderSide(
                      color: Colors.black,
                    ),
                  ),
                  hintText: "Enter the time in minutes",
                  hintStyle: TextStyle(color: Colors.orange),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  )),
            ),
            SizedBox(
              height: 35,
            ),
            Container(
              child: Ink(
                decoration: BoxDecoration(
                  border: Border.all(width: 1),
                  color: Colors.green,
                ),
                child: InkWell(
                  //borderRadius: BorderRadius.circular(5),
                  onTap: () =>setState(() => _count6--),
                  child: Padding(
                    padding: EdgeInsets.all(5),
                    child:
                    Icon(Icons.remove_outlined,size: 18,),
                    //Text(' 0 ',style: TextStyle(fontSize: 25),),
                    //Icon(Icons.add_outlined),
                  ),
                ),
                //),
              ),
            ),
            Text('$_count6',style: TextStyle(fontSize: 40),),
            Container(
              child: Ink(
                decoration: BoxDecoration(
                  border: Border.all(width: 1),
                  color: Colors.green,
                ),
                child: InkWell(
                  //borderRadius: BorderRadius.circular(5),
                  onTap: () =>setState(() => _count6++),
                  child: Padding(
                    padding: EdgeInsets.all(5),
                    child:
                    Icon(Icons.add_outlined,size: 18,),
                    //Text(' 0 ',style: TextStyle(fontSize: 25),),
                    //Icon(Icons.add_outlined),
                  ),
                ),
                //),
              ),
            ),
            SizedBox(
              height: 40,
            ),
            ElevatedButton(
              child: Text('Continue',style: TextStyle(fontSize: 40),),onPressed: (){
              Navigator.push(context, MaterialPageRoute(builder: (context)=> const DonePage()),);
            },style: ElevatedButton.styleFrom(primary: Colors.orangeAccent),
            ),
          ],
        ),
      ),
    );
  }
}
