import 'package:flutter/material.dart';
import 'package:foodiie_app/donepage.dart';

class MyMomos extends StatefulWidget {
  const MyMomos({Key? key}) : super(key: key);

  @override
  State<MyMomos> createState() => _MyMomosState();
}

class _MyMomosState extends State<MyMomos> {
  int _count5=0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0.0,
        title: Text("",textAlign: TextAlign.center,style: TextStyle(fontSize: 30)),
        backgroundColor: Colors.orange,
      ),
      body: Center(
        child: Column(
          children: [
            Image.asset('assets/momos_1.jpg'),
            Text('Momos\n₹80',style: TextStyle(fontSize: 30,fontWeight: FontWeight.bold),),
            Text('\nDescription : Spicy Hot Momos',style: TextStyle(fontSize: 20),),
            SizedBox(
              height: 20,
            ),
            TextField(
              style: TextStyle(color: Colors.orange),
              decoration: InputDecoration(
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: BorderSide(
                      color: Colors.orange,
                    ),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: BorderSide(
                      color: Colors.black,
                    ),
                  ),
                  hintText: "Enter the time in minutes",
                  hintStyle: TextStyle(color: Colors.orange),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  )),
            ),
            SizedBox(
              height: 35,
            ),
            Container(
              child: Ink(
                decoration: BoxDecoration(
                  border: Border.all(width: 1),
                  color: Colors.green,
                ),
                child: InkWell(
                  //borderRadius: BorderRadius.circular(5),
                  onTap: () =>setState(() => _count5--),
                  child: Padding(
                    padding: EdgeInsets.all(5),
                    child:
                    Icon(Icons.remove_outlined,size: 18,),
                    //Text(' 0 ',style: TextStyle(fontSize: 25),),
                    //Icon(Icons.add_outlined),
                  ),
                ),
                //),
              ),
            ),
            Text('$_count5',style: TextStyle(fontSize: 40),),
            Container(
              child: Ink(
                decoration: BoxDecoration(
                  border: Border.all(width: 1),
                  color: Colors.green,
                ),
                child: InkWell(
                  //borderRadius: BorderRadius.circular(5),
                  onTap: () =>setState(() => _count5++),
                  child: Padding(
                    padding: EdgeInsets.all(5),
                    child:
                    Icon(Icons.add_outlined,size: 18,),
                    //Text(' 0 ',style: TextStyle(fontSize: 25),),
                    //Icon(Icons.add_outlined),
                  ),
                ),
                //),
              ),
            ),
            SizedBox(
              height: 40,
            ),
            ElevatedButton(
              child: Text('Continue',style: TextStyle(fontSize: 40),),onPressed: (){
              Navigator.push(context, MaterialPageRoute(builder: (context)=> const DonePage()),);
            },style: ElevatedButton.styleFrom(primary: Colors.orangeAccent),
            ),
          ],
        ),
      ),
    );
  }
}
