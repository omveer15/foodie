import 'package:flutter/material.dart';
import 'package:foodiie_app/login.dart';

class Welcome extends StatefulWidget {
  const Welcome({Key? key}) : super(key: key);

  @override
  State<Welcome> createState() => _WelcomeState();
}

class _WelcomeState extends State<Welcome> {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Scaffold(
        body: Center(
          child: Column(
            children: <Widget>[
              Text("Welcome to Foodie!",style: TextStyle(color: Colors.orange, fontSize: 40,
                  fontStyle: FontStyle.normal,fontWeight: FontWeight.bold,height: 5),),
              Image.asset('assets/image1.png'),
              Text("Let's Eat",style: TextStyle(color: Colors.orange, fontSize: 30,
                  fontStyle: FontStyle.normal,fontWeight: FontWeight.bold),),
              SizedBox(
                height: 30,
              ),
              CircleAvatar(
                radius: 30,
                backgroundColor: Color(0xffef8e2e),
                child: IconButton(
                  color: Colors.white,
                  onPressed: (){ Navigator.push(context, MaterialPageRoute(builder: (context)=> const MyLogin()),);},
                  icon: Icon(Icons.arrow_forward),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
